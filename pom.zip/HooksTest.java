package stepDefinitions;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.lng.bat.PensionDC1C.CustomDriver;
import org.lng.bat.PensionDC1C.GlobalConstants;
import org.openqa.selenium.WebDriver;

import cucumber.api.Scenario;
import cucumber.api.Result.Type;
import cucumber.api.java.After;
import cucumber.api.java.AfterStep;
import cucumber.api.java.Before;
import cucumber.api.java.BeforeStep;
import cucumber.runtime.model.CucumberFeature;
import customerRunner.CustomAbstractTestNGCucumberTests;
import customerRunner.CustomTestNGCucumberRunner;
import utilslng.CsvUtils;
import utilslng.PropUtils;
import utilslng.ExcelUtils;


public class HooksTest {

	public static String ScenarioName =null;
	
	private CustomDriver customDriver;
	private WebDriver driver;
	private ExcelUtils eu;
	
	public HooksTest(CustomDriver customDriver ) throws IOException {
		this.customDriver =customDriver;
		this.driver=customDriver.getDriver();
		
	}
	

	@BeforeStep
	public void beforeClassSteps () throws IOException{
		//System.out.println("I was here at before Step");
	}

	/**
	 * This method will be executed every time before running any Scenario. 
	 * @param Scenario Object is parameterised so that its name could be used for retriving data from excel and update status in excel
	 * @throws IOException
	 */
	@Before
	public void getScenarioName(Scenario scenario) throws IOException{ 
		ScenarioName= scenario.getName();
		
		
		PropUtils du = new PropUtils();
		du.clearPropFile();
		PropUtils.setPropLoad("Scenario", ScenarioName);
/*		CustomAbstractTestNGCucumberTests customAbstractTestNGCucumberTests = new CustomAbstractTestNGCucumberTests();
		Object[][] scenarioUpdate= customAbstractTestNGCucumberTests.scenarios();
		
		 for (Object[] feature : scenarioUpdate) {
			 for (Object scenario1 : feature){
				 System.out.println("scenario1: "+ scenario1.equals(ScenarioName));
			 }
		 }
		*/
		
		org.junit.Assume.assumeFalse(true);
		
	}

	@AfterStep
	
	public static void writeExtentReport() {
		//Reporter.loadXMLConfig(new File(FileReaderManager.getInstance().getConfigReader().getReportConfigPath()));

		//System.out.println("I was here in after Step");
	}

	@After
	public void Result(Scenario testScenario) throws Exception{

		String lineNumber= testScenario.getId();
		String[] splitLineNumber= lineNumber.split(":");
		int len= splitLineNumber.length;

		String ScenarioName1= ScenarioName+" "+ "Scenario"+splitLineNumber[len-1];
		System.out.println("ScenarioName1: "+ScenarioName1);

		customDriver.tearDownDriver(testScenario, ScenarioName1, driver);
	}

	@BeforeClass
	public static void setup() throws IOException {

		PropUtils.createFile(GlobalConstants.GRESULTSLOC);
		PropUtils.createFile(GlobalConstants.GSCREENSHOTLOC);
		String [] value =null; 
		ExcelUtils eu= ExcelUtils.getInstance(GlobalConstants.GTESTSCENARIOFILE);
		eu.setExcelColArray(System.getProperty("applicationName"), GlobalConstants.GEXECUTEDSELENIUM, value);

	}

	@AfterClass
	public static void teardown() {
	}
}
