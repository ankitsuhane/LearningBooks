package org.lng.bat.PensionDC1C;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.lng.bat.PensionDC1C.*;

import org.openqa.selenium.OutputType;
import cucumber.api.Result.Type;
import cucumber.api.Scenario;
import utilslng.PropUtils;
import utilslng.ExcelUtils;

/**
 * CustomDriver Class
 * This class is written to Initialize Driver for IE, Chrome and Firefox browsers and to call the Screenshot functionality. 
 * @author msp6962
 */

public class CustomDriver {

	private Objects objects; 
	private WebDriver driver;
	private static Logger log = LogManager.getLogger(Objects.class.getName());

	/**
	 * getDriver method
	 * This method is written to return the driver instance 
	 * @author msp6962
	 */
	public WebDriver getDriver() {
		return driver;
	}
	/**
	 * getObjects method
	 * This method is written to return the Object class instance 
	 * @author msp6962
	 * @see Object Class
	 */
	public Objects getObjects() {
		return objects;
	}
	
	/**
	 * launchBrowser method
	 * This method is written to Initialize Driver browser, Objects class and other driver capabilities 
	 * implicitAppTimeout is a variable that is in Global parameters file that define the minimal time application should wait before action on any object.
	 * @author msp6962
	 * @see Object Class
	 */

	public void launchBrowser(){
		driver = getBrowserDriver();
		objects = Objects.getInstance(driver);
		//driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS); //Page load time out
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(GlobalConstants.GIMPLICITAPPTIMEOUT, TimeUnit.SECONDS);
		objects.browserMaximize();
	}

	/**
	 * getBrowserDriver method
	 * This method is written to Initialize Driver browser Chrome, Chrome headless,FireFox or IE  
	 * @author msp6962
	 * @see Object Class
	 */

	private WebDriver getBrowserDriver() {

		//String browserName= System.getProperty("browserName").toUpperCase();
		String browserName= "CHROME"; //When you are not running using Maven/Jenkins
		CustomChrome cc;
		switch (browserName){
		case "CHROME": 
			cc = new CustomChrome();
			return driver = cc.setChromeNormal();
		case "IE":
			System.setProperty(GlobalConstants.GIEDRIVERPROP,  GlobalConstants.GHOMEPATH+GlobalConstants.GTESTRESOURCEPATH+"\\IEDriverServer.exe");
			return driver = new InternetExplorerDriver();

		case "FIREFOX":
			System.setProperty(GlobalConstants.GFIREFOXDRIVERPROP,  GlobalConstants.GHOMEPATH+GlobalConstants.GTESTRESOURCEPATH+"\\geckodriver.exe");
			return driver = new FirefoxDriver();

		case "CHROMEHEADLESS": 
			cc  = new CustomChrome();
			return driver = cc.setChromeHeadless();

		default:
			throw new RuntimeException("Invalid Browser Type: "+browserName);
		}
		
	}
	
	/**
	 *  CustomDriver Constructor
	 *  This Constructor will call the launchBrowser method
	 *  @author msp6962
	 * @throws IOException 
	 */
	
	public CustomDriver() throws IOException {
		if (PropUtils.getPropLoad("uri")!="Windows"){
		launchBrowser();
		}
	}
	
	/**
	 * getScreenshots method
	 * This method is written to get Screenshots.  
	 * 1. with Browser Name explicitly given by the method call 
	 * 2. by passing parameter in Global parameters file. 
	 * @param methodName
	 * @return WebDriver
	 * @throws IOException
	 * @author msp6962
	 * @return Screenshot instance
	 */
	public byte[] getScreenshots(String methodName) throws IOException
	{
		byte[] src= null;

		try{

			log.info("Screenshots method has been executed");
//			File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			src = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.BYTES);
			
			//String screenshotLoc= GlobalConstants.gHomepath+File.separator+GlobalConstants.gScreenshotLoc;

			String screenshotFile= GlobalConstants.GSCREENSHOTLOC+File.separator+methodName+"_"+System.getProperty("propertyName")+"_Screenshot.png";
			
			 Path path = Paths.get(screenshotFile);
			 Files.write(path, src);
			
		}catch(Exception e)
		{
			log.error("Screenshots function got exception", e);
		}
		return src;
	}

	
	/**
	 * tearDownDriver method is used to close the browser and record the Test status into an excel sheet. On failure it also creates a screenshot that will be embed to the report
	 * @param testScenario: This parameter is passed from the test case. It is Instance of Scenario and used to get scenario status  
	 * @param driver: Instance of Webdriver
	 * @throws Exception
	 * @author msp6962
	 */
	public void  tearDownDriver(Scenario testScenario,String ScenarioName, WebDriver driver) throws Exception {
		
		Type currentScenarioResult=testScenario.getStatus();
		ExcelUtils eu = ExcelUtils.getInstance("Test_Scenario.xlsm");
		
		
		
		if (Type.PASSED ==currentScenarioResult){
			System.out.println("Test passed");
			eu.setExcelValue(System.getProperty("applicationName"), ScenarioName, GlobalConstants.GEXECUTEDSELENIUM, "Pass");
		}
		
		else if (Type.FAILED ==currentScenarioResult){
			byte[] screenshotLocation=getScreenshots(testScenario.getName());		
			
			System.out.println("Test failed");
			testScenario.embed(screenshotLocation, "image/png");
			eu.setExcelValue(System.getProperty("applicationName"),ScenarioName, GlobalConstants.GEXECUTEDSELENIUM, "Fail");
		}

		if (driver!=null){
			driver.close();
			driver.quit();
			driver=null;
		}

	}


}
