package org.lng.bat.PensionDC1C;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 * CustomChrome Class
 * This class is written to do set properties on Chrome for both Normal and Headless 
 * @author msp6962
 */

public class CustomChrome {
	
	public CustomChrome() {
		// TODO Auto-generated constructor stub
	}

	
	/**
	 * setChromeNormal method
	 * This method is written to set up chrome browser driver capabilities.  
	 * @return WebDriver
	 * @author msp6962
	 */
	public ChromeDriver setChromeNormal(){
	System.setProperty(GlobalConstants.GCHROMEDRIVERPROP,  GlobalConstants.GHOMEPATH+GlobalConstants.GTESTRESOURCEPATH+"\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	return driver;
	}
	
	/**
	 * setChromeHeadless method
	 * This method will be used to setup the chrome browser Headless capabilities
	 * @return driver will be returned with chrome browser Headless capabilities 
	 * @author msp6962
	 */
	
	public ChromeDriver setChromeHeadless(){
	System.setProperty(GlobalConstants.GCHROMEDRIVERPROP,  GlobalConstants.GHOMEPATH+GlobalConstants.GTESTRESOURCEPATH+"\\chromedriver.exe");
	ChromeOptions options = new ChromeOptions();
	options.setHeadless(true);
	options.setAcceptInsecureCerts(true);
	ChromeDriver driver= new ChromeDriver(options);
	return driver;
	}
}
