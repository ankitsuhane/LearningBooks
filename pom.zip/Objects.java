package org.lng.bat.PensionDC1C;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hpsf.Array;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;


/**
 * Objects Class
 * This class is an abstract helper class to define a lot reusable Webelement operations  like clear, get Text, etc. 
 * @author msp6962
 * 
 */

public class Objects{

	private static Objects objects;
	private static WebDriver wdriver;

	private static Logger log = LogManager.getLogger(Objects.class.getName());

	/**
	 * Objects Constructor
	 * This constructor is written instantiate driver  
	 * @author msp6962
	 */
	
	private Objects(WebDriver driver){
		wdriver = driver;
	}

	/**
	 * getInstance method
	 * This method is written to initialize the Object class instance 
	 * @return object class Singleton instantiation
	 * @author msp6962
	 * @param driver: Webdriver instance
	 */
	public static Objects getInstance(WebDriver driver){
		log.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" has started");

		if(objects == null || wdriver.hashCode() != driver.hashCode())
			objects = new Objects(driver);
		return objects;
	}

	/**
	 * clear method
	 * This method is written to clear the WebElement 
	 * @param element: name of WebElement 
	 * @author msp6962
	 */
	public void clear(WebElement element) {
		try{
			log.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" has started");
			if (isElementPresent(element)) 
				element.clear();
		}catch (Exception e){
			log.error (Thread.currentThread().getStackTrace()[1].getMethodName()+" has got into exception", e);
		}
	}

	/**
	 * getText method
	 * This method is written to get the input text from any webElement
	 * @param element: name of WebElement 
	 * @author msp6962
	 * @return text in the WebElement
	 */
	public String getText(WebElement element){
		String value=null;
		try{
			log.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" has started");

			if (isElementPresent(element)) {
				value = element.getText();
			}

		}catch (Exception e){
			log.error (Thread.currentThread().getStackTrace()[1].getMethodName()+" has got into exception", e);
		}
		return value;
	}

	/**
	 * clearAndSendKeys method
	 * This method is written to get the input text from any webElement
	 * @param element: name of WebElement 
	 * @param value: Value that you want to type/write in the WebElement
	 * @author msp6962
	 */
	public void clearAndSendKeys(WebElement element, String value) {
		try{
			log.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" has started");

			if (isElementPresent(element)) {
				element.clear();
				element.sendKeys(Keys.CONTROL + "a");
				element.sendKeys(value);
			}
		}catch (Exception e){
			log.error (Thread.currentThread().getStackTrace()[1].getMethodName()+" has got into exception", e);
		}
	}

	/**
	 * isElementPresent method
	 * This method is verify whether Element is present in the Webpage
	 * @param element: name of WebElement 
	 * @return Boolean value that specify whether Element is present in the Webpage
	 * @author msp6962
	 */
	public static boolean isElementPresent(WebElement element) {

		boolean isPresent = element.isDisplayed();
		return isPresent;
	}

	/**
	 * Click method
	 * This method is click a webelement in webpage
	 * @param element: name of WebElement 
	 * @author msp6962
	 */
	public void Click(WebElement element){
		element.click();
	}

	/**
	 * waitForClick method
	 * This method is written to enable wait for an Element to be clickable before clicking it
	 * @param element: name of WebElement 
	 * @author msp6962
	 * @return Method will return the WebElement, which you were waiting 
	 */
	public WebElement waitForClick(WebElement element) {
		FluentWait<WebDriver> wait = waitForElement(GlobalConstants.GFLUNETWAITTIMEOUTSEC, GlobalConstants.GFLUNETWAITPOOLINGTIMEOUTMILI);
		WebElement element1= wait.until(ExpectedConditions.elementToBeClickable(element));
		return element1;
	}

	/**
	 * selectCheckBox method
	 * This method is written to select a value from the checkbox
	 * @param element: name of WebElement 
	 * @author msp6962
	 */
	public void selectCheckBox(WebElement element) {
		if(!isIselected(element))
			element.click();
	}

	/**
	 * unSelectCheckBox method
	 * This method is written to unselect a value from the checkbox
	 * @param element: name of WebElement 
	 * @author msp6962
	 */
	public void unSelectCheckBox(WebElement element) {
		if(isIselected(element))
			element.click();
	}


	/**
	 * isIselected method
	 * This method is written to verify whether a webelement is selected.
	 * @param element: name of WebElement 
	 * @author msp6962
	 * @return Method will return the boolean value for element section
	 */
	
	public boolean isIselected(WebElement element) {
		boolean flag = element.isSelected();
		return flag;
	}


	/**
	 * waitForElement method
	 * This method is written to set up the wait for an webelement before performing any task
	 * @param gFlunetWaitTimeoutSec: Timeout in Sec duration
	 * @param gFlunetWaitPoolingTimeoutMili: Pooling duration in MiliSec duration 
	 * @author msp6962
	 * @return Method will return Fluent wait instance 
	 * @see GlobalConstants
	 */
	public FluentWait<WebDriver> waitForElement(long gFlunetWaitTimeoutSec, long gFlunetWaitPoolingTimeoutMili) {

		// WebDriverWait wait = new WebDriverWait (driver, timeOutInSeconds);
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(wdriver);
		wait
		.ignoring(NoSuchElementException.class)
		.ignoring(ElementNotVisibleException.class)
		.ignoring(StaleElementReferenceException.class)
		.ignoring(ElementNotFoundException.class)
		.withTimeout(Duration.ofSeconds(gFlunetWaitTimeoutSec))
		.pollingEvery(Duration.ofMillis(gFlunetWaitPoolingTimeoutMili));
		return wait;
	}

	/**
	 * getHyperLink method
	 * This method is written to return the Hyperlink
	 * @param element: name of WebElement 
	 * @author msp6962
	 * @return Method will return hyperlink 
	 */
	public String getHyperLink(WebElement element) {
		String link = element.getAttribute("href"); 
		return link;
	} 
	
	/**
	 * browserMoveForward method
	 * This method is written to move browser forward
	 * @author msp6962
	 */
	public void browserMoveForward(){
		wdriver.navigate().forward();
	}

	/**
	 * browserMoveBackword method
	 * This method is written to move browser backward
	 * @author msp6962
	 */

	public void browserMoveBackward(){
		wdriver.navigate().back();
	}


	/**
	 * browserRefresh method
	 * This method is written to move refresh browser
	 * @author msp6962
	 */
	public void browserRefresh(){
		wdriver.navigate().refresh();
	}

	/**
	 * browserMaximize method
	 * This method is written to maximize browser
	 * @author msp6962
	 */
	public void browserMaximize(){
		wdriver.manage().window().maximize();
	}


	/**
	 * selectByVisibleText method
	 * This method is written to select a text  by the visible text in select webelement 
	 * @param element: Name of WebElement
	 * @param text: Text that you want to select
	 * @author msp6962
	 */
	
	public void selectByVisibleText(WebElement element,String text){
		Select select = new Select(element);
		select.selectByVisibleText(text);
	}


	/**
	 * selectByVisibleText method
	 * This method is written to select a text  by its value in select webelement 
	 * @param element: Name of WebElement
	 * @param value: of the webelement that you want to select
	 * @author msp6962
	 */

	public void selectByValue(WebElement element,String value){
		Select select = new Select(element);
		select.selectByValue(value);
	}
	/**
	 * selectgetAllValues method
	 * This method is written to select all the values from select webelement 
	 * @param element: Name of WebElement
	 * @author msp6962
	 * @return list of all the text available in select webelement
	 */
	
	public List<String> selectgetAllValues(WebElement element){
		Select select = new Select(element);
		List <WebElement> options =  select.getOptions();
		List <String> listValue= new LinkedList<String>();

		for (WebElement elements :options){
			listValue.add(elements.getText());
		}	
		return listValue;
	}

	/**
	 * selectByIndex method
	 * This method is written to select values from select webelement by its Index 
	 * @param element: Name of WebElement
	 * @param index: index number of element that you want to select
	 * @author msp6962
	 */

	public void selectByIndex(WebElement element,int index){
		Select select = new Select(element);
		select.selectByIndex(index);
	}

	/**
	 * selectByIndex method
	 * This method is written to return first value in the select webelement 
	 * @param element: Name of WebElement
	 * @author msp6962
	 * @return value  
	 */
	public String getSelectedValue(WebElement element) {
		String value = new Select(element).getFirstSelectedOption().getText();
		return value;
	}



	/**
	 * acceptAlert method
	 * This method is written to accept any alert raised by application 
	 * @author msp6962
	 */
	public void acceptAlert(){
		Alert alert = waitForAlert();
		alert.accept();
	}

	/**
	 * dismissAlert method
	 * This method is written to dismess any alert raised by application 
	 * @author msp6962
	 */
	public void dismissAlert(){
		Alert alert = waitForAlert();
		alert.dismiss();
	}

	/**
	 * setAlertTest method
	 * This method is written to send any data to alert raised by application 
	 * @param args: Argument that you want to send
	 * @author msp6962
	 */

	public void setAlertTest(String args){
		Alert alert = waitForAlert();
		alert.sendKeys(args);
		alert.accept();
	}

	/**
	 * waitForAlert method
	 * This method is written to wait for Alert
	 * @author msp6962
	 * @return Alert object
	 */

	private Alert waitForAlert() {
		FluentWait<WebDriver> wait = waitForElement(GlobalConstants.GFLUNETWAITTIMEOUTSEC, GlobalConstants.GFLUNETWAITPOOLINGTIMEOUTMILI);
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		return alert;
	}

	/**
	 * getAlertText method
	 * This method is written to get the text in Alert
	 * @author msp6962
	 * @return Alert object
	 */

	public String getAlertText(){
		Alert alert = waitForAlert();
		return alert.getText();
	}
	

	/**
	 * actionByIndex method
	 * This method is written to take an action on the drag objects
	 * @param elements: List of WebElement(s) that you want to operate
	 * @author msp6962
	 */

	public void actionByIndex(List<WebElement> elements){
		Actions action = new Actions(wdriver);

		//never unit tested

		int NumberofElements= elements.size();


		try{
			log.info (Thread.currentThread().getStackTrace()[1].getMethodName()+" has started");
			switch (NumberofElements) {
			case 1:
				action.moveToElement(elements.get(0)).pause(Duration.ofSeconds(2)).click().build().perform();

			case 2:
				action.moveToElement(elements.get(0)).pause(Duration.ofSeconds(2)).moveToElement(elements.get(1)).pause(Duration.ofSeconds(2)).
				click().build().perform();
			case 3:
				action.moveToElement(elements.get(0)).pause(Duration.ofSeconds(2)).moveToElement(elements.get(1)).pause(Duration.ofSeconds(2)).
				moveToElement(elements.get(2)).pause(Duration.ofSeconds(2)).
				click().build().perform();
			default:
				break;	
			}
		}catch (Exception e)
		{
			log.error (Thread.currentThread().getStackTrace()[1].getMethodName()+" has got into exception", e);
		}
	}



	/**
	 * waitForWindows method
	 * This method is written to wait on operation until all expected windows opened
	 * @param index number of window that you want to open
	 * @author msp6962
	 */
	
	private void waitForWindows(int index) {
		FluentWait<WebDriver> wait = waitForElement(GlobalConstants.GFLUNETWAITTIMEOUTSEC, GlobalConstants.GFLUNETWAITPOOLINGTIMEOUTMILI);
		wait.until(ExpectedConditions.numberOfWindowsToBe(index));
	}

	/**
	 * switchToChildWindow method
	 * This method is written to move across child windows opened
	 * @param index number of window that you want to open
	 * @author msp6962
	 */
	
	
	public void switchToChildWindow(int index){
	
		ArrayList<String> windowIds = new ArrayList<>(getWindowIds());
		waitForWindows(index);

		if(index < 0 || index > windowIds.size())
			throw new IllegalArgumentException("Index is not valid " + index);

		wdriver.switchTo().window(windowIds.get(index));

	}


	/**
	 * switchToParentWindow method
	 * This method is written to move from any window to parent window
	 * @author msp6962
	 */
	
	public void switchToParentWindow(){
		ArrayList<String> windowIds = new ArrayList<>(getWindowIds());
		wdriver.switchTo().window(windowIds.get(0));
	}


	/**
	 * switchToParentWithCloseChild method
	 * This method is written to move from any window to parent window and close child window
	 * @author msp6962
	 */
	
	public void switchToParentWithCloseChild(){
		ArrayList<String> windowIds = new ArrayList<>(getWindowIds());

		for(int i = 1; i < windowIds.size(); i++){
			wdriver.switchTo().window(windowIds.get(i));
			wdriver.close();
		}

		switchToParentWindow();
	}

	/**
	 * getWindowIds method
	 * This method is written to get all the opened windows
	 * @author msp6962
	 * @return windowIds Collection of Windows id
	 */
	private List<String> getWindowIds(){
		ArrayList<String> windowIds = new ArrayList<>(wdriver.getWindowHandles());
		return Collections.unmodifiableList(windowIds);
	}

	/**
	 * gridOperation enum
	 * This enum is written for the gird operations
	 * @author msp6962
	 */

	public enum gridOperation{
		columnSUM, 
		columnSumExceptSummary,
		rowCount;
	}


	/**
	 * gridFunctions method
	 * This method is written to do operations on Grid
	 * @param tableWebElement: this argument accept the WebElement for the table
	 * @param rowCSSWebElementwithColumnIndex: This argument accept the css values for the column onto which you want to do operation
	 * @param operation: This will accept one of the Enum values from gridOperation
	 * @param noOfSummaryRows: When there is any summary row that you do not want to count then you have to specify the number here. This could be 0 to any integer  
	 * @author msp6962
	 */
	public String gridFunctions(WebElement tableWebElement, String rowCSSWebElementwithColumnIndex, gridOperation operation, int noOfSummaryRows){
		
		log.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" has started");

		try{
			if(tableWebElement!=null && rowCSSWebElementwithColumnIndex!=null){

				int numberOfRows= tableWebElement.findElements(By.cssSelector(rowCSSWebElementwithColumnIndex)).size();
				BigDecimal sum= new BigDecimal("0.00");
				String sumString;

				switch (operation) {
				case rowCount:
					return String.valueOf(numberOfRows);

				case columnSUM:

					for (int i=0;i<numberOfRows;i++){

						String data= tableWebElement.findElements(By.cssSelector(rowCSSWebElementwithColumnIndex)).get(i).getText();
						data = data.replaceAll(GlobalConstants.GREPLACEALLTOMAKEDOUBLE, "");

						BigDecimal sumData= new BigDecimal(data);
						sum =sum.add(sumData);
					}
					sumString=sum.toString();
					return sumString;

				case columnSumExceptSummary:

					for (int i=0;i<numberOfRows;i++){

						String data= tableWebElement.findElements(By.cssSelector(rowCSSWebElementwithColumnIndex)).get(i).getText();
						data = data.replaceAll(GlobalConstants.GREPLACEALLTOMAKEDOUBLE, "");
						BigDecimal sumData= new BigDecimal(data);
						sum =sum.add(sumData);
					}
					sumString=sum.toString();
					return sumString;

				default:
					break;
				}
			}

		}catch (Exception e)
		{
			log.error(Thread.currentThread().getStackTrace()[1].getMethodName()+" has got into exception",e);
		}
		return null;

	}
}